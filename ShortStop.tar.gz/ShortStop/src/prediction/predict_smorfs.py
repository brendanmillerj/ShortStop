from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
import tensorflow as tf
import joblib
 

from ..pipeline import PipelineStructure
from ..utils import check_dir

tf.random.set_seed(2016)

class smORFPredictor(PipelineStructure):
    def __init__(self, args):
        super().__init__(args=args)
        self.set_prediction_attributes()
        
    def align_and_confirm_features(self):
        self.orfs_features_in_training_model = pd.read_csv(self.args.orfs_features_in_training_model)
        self.orfs_to_be_predicted = pd.read_csv(self.args.orfs_to_be_predicted)
        
        # Identify missing features
        missing_features = set(self.orfs_features_in_training_model.columns) - set(self.orfs_to_be_predicted.columns)
        
        # Create a DataFrame with missing features set to 0
        missing_features_df = pd.DataFrame(0.0, index=self.orfs_to_be_predicted.index, columns=list(missing_features), dtype=float)
        
        # Concatenate the original DataFrame with the missing features DataFrame
        self.orfs_to_be_predicted = pd.concat([self.orfs_to_be_predicted, missing_features_df], axis=1)
        
        # Drop features not present in the training model and ensure column order matches the training model
        missing_features_two = set(self.orfs_to_be_predicted.columns) - set(self.orfs_features_in_training_model.columns)
        self.orfs_to_be_predicted = self.orfs_to_be_predicted.drop(columns=missing_features_two)
        self.orfs_to_be_predicted = self.orfs_to_be_predicted[self.orfs_features_in_training_model.columns]
        
        # Make a copy to defragment the DataFrame
        self.orfs_to_be_predicted = self.orfs_to_be_predicted.copy()

         # Save self.orfs_to_be_predicted to a CSV file
        #self.orfs_to_be_predicted.to_csv(f'{self.predictionsDir}/orfs_to_be_predicted_UPDATED.csv', index=False)
        
        # Confirmation message
        print("Confirmed: Your data is appropriately scaled based on the original model's training platform.")


        
    def dansby(self):
        self.align_and_confirm_features()
        orf_ids = self.orfs_to_be_predicted['orf_id']

        # Load the model and make predictions
        model = tf.keras.models.load_model(self.model)
        self.__scaler() 
        predictions = model.predict(self.data) 

        # Prepare the predictions for output
        predictions_df = pd.DataFrame(predictions, columns=['random_decoy', 'intracellular', 'extracellular_secreted'])
        predictions_df['total_positive_percentage'] = predictions_df['intracellular'] + predictions_df['extracellular_secreted']
        predictions_df['orf_id'] = orf_ids
        predictions_df = predictions_df[['orf_id','random_decoy', 'total_positive_percentage']]

        # Save the predictions to a CSV file
        predictions_df.to_csv(f'{self.predictionsDir}/random_vs_decoy_percentages.csv', index=False)

        # Prepare the data for the predicted classes
        labels = np.argmax(predictions, axis=1)
        percentages = np.max(predictions, axis=1)
        predicted_classes = pd.DataFrame({'orf_id': orf_ids, 'pred_label': labels, 'class_prediction_percentage': percentages})
        predicted_classes = predicted_classes.sort_values(by=['class_prediction_percentage'], ascending=False)

        # Save the predicted classes to a CSV file
        predicted_classes.to_csv(f'{self.predictionsDir}/all_class_percentages.csv', index=False)

        # Save each predicted class to a separate CSV file
        for class_label, class_name in enumerate(['decoy_percentages_smorfs', 'intracellular_smorfs', 'secreted_smorfs']):
            class_data = predicted_classes[predicted_classes['pred_label'] == class_label]
            class_data.to_csv(f'{self.predictionsDir}/{class_name}.csv', index=False)
        
    
    def __scaler(self):
        self.scaler = joblib.load(self.args.model_scaler)
        
        self.__aa_split()
        self.__dna_split()
        
        # print the shape of the data
        print(f"Number of DNA features being used to predict: {self.dna_data.shape[1]}")
        print(f"Number of AA features being used to predict: {self.aa_data.shape[1]}")
        
        
        self.data = np.concatenate((self.dna_data, self.aa_data), axis=1)
        
        self.data =self.scaler.transform(self.data)
        
    def __dna_split(self):
        self.dna_data = self.orfs_to_be_predicted.loc[:, self.orfs_to_be_predicted.columns.str.startswith('5_prime') | self.orfs_to_be_predicted.columns.str.startswith('3_prime') | self.orfs_to_be_predicted.columns.str.startswith('kozak') | self.orfs_to_be_predicted.columns.str.startswith('first_50')]
        self.dna_data = self.dna_data.to_numpy()
        
    def __aa_split(self):
        self.aa_data = self.orfs_to_be_predicted.drop(self.orfs_to_be_predicted .filter(regex='3_prime').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='5_prime').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='kozak').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='first_50').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='label').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='type').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='orf_id').columns, axis=1)
        self.aa_data = self.aa_data.drop(self.aa_data.filter(regex='local').columns, axis=1)
        self.aa_data = self.aa_data.to_numpy()