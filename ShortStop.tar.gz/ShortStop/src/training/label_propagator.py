import time
from collections import Counter
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.semi_supervised import LabelSpreading
import plotly.express as px
import matplotlib.pyplot as plt
import umap

from ..pipeline import PipelineStructure


class LabelPropagator(PipelineStructure):
    def __init__(self, args):
        super().__init__(args=args)
        self.set_training_attributes()

        self.reducedFeatures = None
        self.labelPropagated = None

    def reduce_features(self):
        features = pd.read_csv(self.orfsFeatures)

        # Prepare the data for UMAP
        orf_id = features['orf_id']
        type = features['type']
        local = features['local']
        label = features['label']
        self.labels = label

        # Drop orf_id, type, and local to just include float values
        features = features.drop(['orf_id', 'local', 'type', 'label'], axis=1)

        # Remove CDS kmers
        features = features.loc[:, ~features.columns.str.startswith('cds')]

        # Standardize the data
        scaler = StandardScaler()
        scaled_features = scaler.fit_transform(features)

        # Carry out data reduction using UMAP
        time_start = time.time()
        n_neighbors = self.args.n_neighbors 
        n_neighbors = float(n_neighbors)
        umap_model = umap.UMAP(n_components=3, n_neighbors= n_neighbors)  # Specify the desired number of components as 3 for 3D
        umap_result = umap_model.fit_transform(scaled_features)

        # Add orf_id, type, and local to umap_result
        reduced_features = pd.DataFrame(umap_result)
        reduced_features['orf_id'] = orf_id
        reduced_features['type'] = type
        reduced_features['local'] = local

        # Change 0 column name to x, 1 to y, and 2 to z
        reduced_features = reduced_features.rename(columns={0: "umap_0", 1: "umap_1", 2: "umap_2"})
        reduced_features = reduced_features[reduced_features.local != "Missing"] #Remove ORFs with missing cellular compartment annotation
        self.reducedFeatures = reduced_features
        
        print(f"UMAP took {time.time() - time_start:.2f} seconds")

    def plot_3d_scatter(self):
        fig = px.scatter_3d(self.reducedFeatures, x="umap_0", y="umap_1", z="umap_2", color="local",
                            color_discrete_map={"Cytoplasm": "yellow", "Secreted": "blue", "Random": "black",
                                                "ToBePredicted": "red"})
        fig.update_traces(marker={'size': 3, 'opacity': 1})
        fig.update_layout(hovermode="y")
        fig.write_html(self.umapHtml, include_plotlyjs=True, full_html=True)

    def __prepare_data_for_label_propagation(self):
        # Prepare the data for label propagation
        labels = self.reducedFeatures["local"].values.tolist()
        features = self.reducedFeatures[["umap_0", "umap_1", "umap_2"]]
        mapping = {"ToBePredicted": -1, "Random": 0, "Missing": -1, "Cytoplasm": 1, "Secreted": 2}
        labels = [mapping.get(x, x) for x in labels]
        Counter(labels)
        return features, labels

    def propagate_labels(self):
        label_prop_model = LabelSpreading(alpha = 0.2, kernel='rbf')
        features, labels = self.__prepare_data_for_label_propagation()
        reduced_features = self.reducedFeatures
        gamma = int(self.args.gamma)
        
        # Keep tuning gamma until the ratio of between-group to within-group variance is greater than 1 for the "label_prop" column
        prev_ratio = 0.01 #Initialize to a small value
        while True:
            # Update the gamma value in the LabelSpreading model
            label_prop_model.set_params(gamma=gamma)
            
            # Fit the model with the updated gamma value
            label_prop_model.fit(features, labels)
            
            # Predict labels for all data points with the updated model
            label_prop = label_prop_model.predict(features)
            
            # Add the predicted labels to the "reduced_features" DataFrame
            reduced_features["label_prop"] = label_prop
            
            # Recode the predicted labels to their corresponding string labels
            mapping = {0: "Random", 1: "Cytoplasm", 2: "Secreted"}
            reduced_features["label_prop"] = reduced_features["label_prop"].replace(mapping)
            
            # Calculate within-group variance
            within_group_var = reduced_features.groupby('label_prop').var(numeric_only = True)
            
            # Calculate between-group variance
            between_group_var = reduced_features.groupby('label_prop').mean(numeric_only = True).var(numeric_only = True)
            
            # Calculate the ratio of between-group to within-group variance 
            ratio = between_group_var / within_group_var
            ratio_max = ratio.max()[0]

            # Check to see if the ratio is greater than 1 and if the ratio is decreasing
            if ratio.iloc[0, 0] > 1 and ratio.iloc[1, 0] > 1 and ratio.iloc[2, 0] > 1 and prev_ratio is not None or ratio_max <= prev_ratio:
                break
                
            # Save the current ratio as the previous ratio
            prev_ratio = ratio_max.copy()
            
            # Update gamma
            gamma +=1
            
            # If gamma > 100, break the loop
            if gamma > 100:
                print("Classes don't appear to be separating well after gamma > 100. Exiting loop. Data reduction via UMAP may not be appropriate. UMAP is primarily used for visualization. Label propagation is not necessary but might provide greater informatino for training purposes.")
                break

        print("Final gamma value: ", gamma)
        
        self.labelPropagated = label_prop
        

    def plot_propagated_3d_scatter(self):
        """
        Generates a 3-dimensional scatter plot for the data after label propagation
        :return:
        """
        reduced_features = self.reducedFeatures
        
        # Add the label_prop column to the reduced_features DataFrame
        reduced_features["label_prop"] = self.labelPropagated
        mapping = {0: "Random", 1: "Cytoplasm", 2: "Secreted"}
        reduced_features["label_prop"] = [mapping.get(x, x) for x in reduced_features["label_prop"]]
        reduced_features["label_prop"] = reduced_features["label_prop"].astype(object)

        fig = px.scatter_3d(reduced_features, x="umap_0", y="umap_1", z="umap_2", color="label_prop",
                            color_discrete_map={"Random": "black", "Secreted": "blue", "Cytoplasm": "yellow"})
        fig.update_traces(marker={'size': 2.5, 'opacity': 1})
        fig.update_layout(hovermode="y")
        fig.write_html(self.umapHtmlPropagated, include_plotlyjs=True, full_html=True)

    def create_label_propagation_data_frame(self):
        df = self.reducedFeatures
        column_name = "label_prop"
        df = df[[column_name, "type"]]
        df = df.groupby([column_name, "type"]).size().reset_index(name="count")
        df = df.pivot(index=column_name, columns="type", values="count")
        df = df.fillna(0)

        if self.args.propagate == "propagate":
            df.to_csv(f"{self.featuresDir}/label_propagation_confusion_matrix.csv", index=True)
        
        self.reducedFeatures.to_csv(self.labelPropagationDF, index=False)
        df.to_csv(f"{self.featuresDir}/label_spreading_confusion_matrix.csv", index=True)
        
    def create_original_data_frame(self):
        df =  pd.read_csv(self.orfsFeatures)
        # Create new column called "label_prop" and set it to the value of the "local" column
        df["label_prop"] = df["local"]
        # Remove rows with "ToBePredicted" and "Missing" values in the "local" column
        df = df[df.local != "ToBePredicted"]
        df = df[df.local != "Missing"]
        df.to_csv(self.labelPropagationDF, index=False)