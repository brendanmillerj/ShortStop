import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import randint as sp_randint
from sklearn.model_selection import RandomizedSearchCV, train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Concatenate, BatchNormalization, Activation, Dropout
from tensorflow.keras.utils import to_categorical, plot_model
from tensorflow.keras.optimizers import Adam
from scikeras.wrappers import KerasClassifier


from ..pipeline import PipelineStructure


class NeuralNetworkCustomFeatures(PipelineStructure):
    def __init__(self, args):
        super().__init__(args=args)
        self.set_training_attributes()

        self.labels = None
        self.orfIds = None
        self.data = None

        # neural network layers
        self.inputLayer1, self.inputLayer2 = None, None
        self.outputLayer = None

        # split data
        self.labelTrain = None
        self.Test = None
        self.labelTest = None
        self.orfTrain = None
        self.orfTest = None

        self.history = None
        self.best_model = None
        self.scaler = None

    def clean_data(self):
        # Import features
        features = pd.read_csv(self.orfsFeatures)

        # Remove missing cellular compartment labels
        features = features[features.local != 'Unknown']

        # Drop features that start with local, type, so that we can keep only the amino acid and DNA features
        features = features.drop(features.filter(regex='local').columns, axis=1)
        features = features.drop(features.filter(regex='type').columns, axis=1)

        # Import labels
        labels = pd.read_csv(self.labelPropagationDF)
        labels = labels[['orf_id', 'label_prop']]
        
        # Remove missing labels that were not propagated
        labels = labels[labels.label_prop != 'Unknown']
        labels.head()

        # Merge features and labels
        df = pd.merge(features, labels, on='orf_id')
        df = df.drop(df.filter(regex='type').columns, axis=1)

        # Create a new array with only amino acid features
        regex_patterns = ['label', 'orf_id']
        cleaned_df = df.drop(columns=[col for pattern in regex_patterns for col in df.filter(regex=pattern).columns])
        self.feauture_data = cleaned_df.to_numpy()

        # Create a new array with only orf ids
        self.orfIds = df['orf_id']

        # Create a new array with only labels
        labels = df['label_prop']

        # Convert labels to one hot encoding
        mapping = {"RiboSeq": -1, "Random": 0, "Unknown": -1, "Cytoplasm": 1, "Secreted": 2} 
        labels = [mapping.get(x, x) for x in labels]
        labels = to_categorical(labels)
        self.labels = np.array(labels)

    def split_data_double_play(self):
        # Split the data into training and testing sets
        (
            feauture_data, 
            self.feauture_dataTest, 
            self.labelTrain, 
            self.labelTest, 
            self.orfTrain, 
            self.orfTest
        ) = train_test_split(
            self.feauture_data, 
            self.labels, 
            self.orfIds, 
            test_size=0.2, 
            random_state=2016, 
            stratify=self.labels
        )
        print(self.feauture_data.shape)
        
        # Scale the data, so that the neural network can be trained,tested, and future data can be predicted with the same scaling parameters
        scaler = StandardScaler()
        self.fit = scaler.fit(feauture_data, axis=1)
        self.data = scaler.fit_transform(feauture_data, axis=1)
        np.savetxt(f"{self.modelsDir}/scaler_params.csv", np.vstack([scaler.mean_, scaler.scale_]), delimiter=",") # This will be used to scale future data for prediction
    

    def tune_hyperparameters(self):

        def create_model(data = None):
            shape = data.shape[1]

            def define_model(nodes_layer_one=512, nodes_layer_two = 128, dropout_rate=0.4, learning_rate=0.0001):
                input_data = Input(shape=(shape,))
                x = input_data
                x = Dropout(dropout_rate)(Activation('relu')(BatchNormalization()(Dense(nodes_layer_one)(x))))
                x = Dropout(dropout_rate)(Activation('relu')(BatchNormalization()(Dense(int(nodes_layer_two))(x))))
                output = Dense(3, activation='softmax')(x)
                model = Model(inputs=input_data, outputs=output)
                model.compile(loss='categorical_crossentropy', optimizer=Adam(learning_rate, clipnorm=1.0), metrics=['accuracy'])
                return model

            return define_model
        
        # Load scaled parameters for StandardScaler
        params = np.loadtxt(f"{self.modelsDir}/scaler_params.csv", delimiter=",") # This just loads back in the mean and standard deviation of the training data
        # Create StandardScaler object with loaded parameters
        scaler = StandardScaler()
        scaler.mean_ = params[0] 
        scaler.scale_ = params[1]
        self.scaler = scaler

        # Create a KerasClassifier object
        model = KerasClassifier(build_fn=create_model(self.data), verbose=0)

        # Define the grid search parameters
        batch_size = [64, 128]
        epochs = [24, 48]
        validation_split = [0.2]
        nodes_layer_one = [256, 512]
        nodes_layer_two = [0, 32] # This is the second layer of the neural network, and is set to 0 to indicate that the second layer is not used for tuning
        dropout_rate = [0.25, 0.5]
        learning_rate = [0.00001, 0.0001]
        param_grid = dict(batch_size=batch_size, epochs=epochs, validation_split=validation_split, nodes_layer_one=nodes_layer_one, nodes_layer_two=nodes_layer_two, dropout_rate=dropout_rate, learning_rate=learning_rate)

        # Perform the grid search
        grid = GridSearchCV(estimator=model, param_grid=param_grid, cv=3, n_jobs=-1)
        grid_result = grid.fit(self.data, self.labelTrain)

        # Get the best model
        self.best_model = grid_result.best_estimator_.model

        # Print the best hyperparameters and the corresponding score
        print('Best score:', grid_result.best_score_)
        print('Best params:', grid_result.best_params_)
        
        plt.clf()
        plt.plot(self.best_model.history.history['accuracy'], label='train accuracy')
        plt.plot(self.best_model.history.history['val_accuracy'], label='val accuracy')
        plt.plot(self.best_model.history.history['loss'], label='train loss')
        plt.plot(self.best_model.history.history['val_loss'], label='val loss')
        plt.title('Model accuracy and loss')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy/Loss')
        plt.legend(loc='best')
        plt.savefig(self.modelAccuracyPlot, dpi=300)
        

    def test_model(self):
        print("\nInitiating model testing.\n")
        
        test_data = np.concatenate((self.dnaTest, self.aaTest), axis=1)

        # standardize and scale the test data
        test_data = self.scaler.transform(test_data)

        # Evaluate the model
        test_acc = self.best_model.evaluate(test_data, self.labelTest)
        print('Test accuracy:', test_acc)

        probs = self.best_model.predict(test_data)
        pred_labels = np.argmax(probs, axis=1)

        # Create a confusion matrix
        cm = confusion_matrix(self.labelTest.argmax(axis=1), pred_labels)

        # Compute precision, recall, and F1 score
        precision = precision_score(self.labelTest.argmax(axis=1), pred_labels, average=None)
        recall = recall_score(self.labelTest.argmax(axis=1), pred_labels, average=None)
        f1score = f1_score(self.labelTest.argmax(axis=1), pred_labels, average=None)

        # print results
        print('Confusion Matrix:\n', cm)
        print('\nPrecision:', precision)
        print('Recall:', recall)
        print('F1 Score:', f1score, '\n')

        # Save model
        self.best_model.save(f'{self.modelsDir}/best_model.h5')

    def plot_model_architecture(self):
        plt.clf()
        plot_model(self.best_model, show_shapes=True, to_file=self.modelArchitecturePlot)
