import sys
import random
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from ..pipeline import PipelineStructure
from ..converters import FeatureExtraction


class NegativeSet(PipelineStructure):
    def __init__(self, args):
        super().__init__(args=args)
        self.set_training_attributes()
        self.__get_smorfs_metrics()
        self.codonTable = self.__get_codon_table()
        self.randomSequences = []
        self.randomDF = None
        self.uniprot_smorfs_random = None

    def __get_smorfs_metrics(self):
        
        unknown_sequences = pd.read_csv(self.unknown_sequences)
        unknown_sequences = unknown_sequences.fillna('X')
        self.unknown_sequences = unknown_sequences
        
        # Calculate mean and standard deviation of length of utr_5 for type 'unknown_orfs', ie, those that are not positively labeled but are not decoys
        self.mean_5 = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs']['utr_5'].apply(
            len).mean()
        self.std_5 = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs']['utr_5'].apply(
            len).std()

        # Calculate mean and standard deviation of length of utr_3 for type 'unknown_orfs, ie, those that are not positively labeled but are not decoys
        self.mean_3 = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs']['utr_3'].apply(
            len).mean()
        self.std_3 = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs']['utr_3'].apply(
            len).std()

        # Calculate mean and standard deviation of length of aa unknown_orfs, ie, those that are not positively labeled but are not decoys
        self.mean_aa = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs']['aa_seq'].apply(
            len).mean()
        self.std_aa = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs']['aa_seq'].apply(
            len).std()*1.25
        self.unknown_orfsAASeq = unknown_sequences[unknown_sequences['type'] == 'unknown_orfs'][
            'aa_seq'].tolist()

        # Print mean and standard deviation of length of utr_5, utr_3, and aa for type 'unknown_orfs
        print("     Here is the average length and standard deviation of your smORFs that the random/decoy generator is using:")
        print("         -- Mean length of amino acid sequence: ", self.mean_aa)
        print("         -- 1.25 Standard deviation of length of amino acid sequence: ", self.std_aa)
                

    @staticmethod
    def __get_codon_table():
        codon_table = {'A': ['GCT', 'GCC', 'GCA', 'GCG'],
                       'R': ['CGT', 'CGC', 'CGA', 'CGG', 'AGA', 'AGG'],
                       'N': ['AAT', 'AAC'],
                       'D': ['GAT', 'GAC'],
                       'C': ['TGT', 'TGC'],
                       'Q': ['CAA', 'CAG'],
                       'E': ['GAA', 'GAG'],
                       'G': ['GGT', 'GGC', 'GGA', 'GGG'],
                       'H': ['CAT', 'CAC'],
                       'I': ['ATT', 'ATC', 'ATA'],
                       'L': ['TTA', 'TTG', 'CTT', 'CTC', 'CTA', 'CTG'],
                       'K': ['AAA', 'AAG'],
                       'M': ['ATG'],
                       'F': ['TTT', 'TTC'],
                       'P': ['CCT', 'CCC', 'CCA', 'CCG'],
                       'S': ['TCT', 'TCC', 'TCA', 'TCG', 'AGT', 'AGC'],
                       'T': ['ACT', 'ACC', 'ACA', 'ACG'],
                       'W': ['TGG'],
                       'Y': ['TAT', 'TAC'],
                       'V': ['GTT', 'GTC', 'GTA', 'GTG'],
                       '*': ['TAA', 'TAG', 'TGA']}
        return codon_table

    @staticmethod
    def protein_shuffler(protein_list, length):
        amino_acids = ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W','Y']
        probabilities = {}
        for acid in amino_acids:
            probabilities[acid] = 0
        for protein in protein_list:
            for acid in amino_acids:
                probabilities[acid] += protein.count(acid)
        total_acids = sum(probabilities.values())
        for acid in probabilities:
            probabilities[acid] /= total_acids
        protein = ''
        for i in range(length):
            acid = random.choices(list(probabilities.keys()), list(probabilities.values()))[0]
            protein += acid
        return protein

    # Move the first 'M' to the beginning of the sequence to make it a valid protein sequence
    @staticmethod
    def move_M(seq):
        """Move the first 'M' to the beginning of the sequence."""
        if seq[0] == 'M':
            return seq
        elif seq[0] != 'M':
            for i in range(len(seq)):
                if seq[i] == 'M':
                    return seq[i:] + seq[:i]
                else:
                    return "M" + seq

    @staticmethod
    def random_dna(length):
        """Generate a random DNA sequence of a given length."""
        dna = ''
        suffix = ''
        if random.random() < 0.1:
            suffix = 'XX'
        elif random.random() < 0.05:
            suffix = 'XXX'
        elif random.random() < 0.025:
            suffix = 'XXXX'
        
        for i in range(length - len(suffix)):
            dna += random.choice('ATGC')
        
        dna += suffix
        return dna
    
    def calculate_x_starting_probabilities(self, utr_list):
        x_startings_counts = {i: 0 for i in range(0, 25)}  # Include 0 for sequences with no "X" endings
        for utr in utr_list:
            found_x_ending = False
            for i in range(24, 0, -1):  # Start from 10 "X"s to 1 "X" to ensure checking for longest "X" string first
                if utr.startswith('X' * i):
                    x_startings_counts[i] += 1
                    found_x_ending = True
                    break
            if not found_x_ending:
                x_startings_counts[0] += 1  # Increment count for sequences with no "X" endings

        total_count = sum(x_startings_counts.values())
        if total_count > 0:
            return {i: count / total_count for i, count in x_startings_counts.items()}
        else:
            return {i: 0 for i in range(0, 25)}  # Provide a default value in case of no data
        
    def calculate_x_ending_probabilities(self, utr_list):
        x_endings_counts = {i: 0 for i in range(0, 25)}  # Include 0 for sequences with no "X" endings
        for utr in utr_list:
            found_x_ending = False
            for i in range(24, 0, -1):  # Start from 10 "X"s to 1 "X" to ensure checking for longest "X" string first
                if utr.endswith('X' * i):
                    x_endings_counts[i] += 1
                    found_x_ending = True
                    break
            if not found_x_ending:
                x_endings_counts[0] += 1  # Increment count for sequences with no "X" endings

        total_count = sum(x_endings_counts.values())
        if total_count > 0:
            return {i: count / total_count for i, count in x_endings_counts.items()}
        else:
            return {i: 0 for i in range(0, 25)}  # Provide a default value in case of no data


    def utr_5_shuffler(self, utr_list, target_length=25):
        x_ending_probabilities = self.calculate_x_ending_probabilities(utr_list)
        nucleotides = ['A', 'C', 'G', 'T']
        probabilities = {acid: 0 for acid in nucleotides}

        for utr in utr_list:
            for acid in nucleotides:
                probabilities[acid] += utr.count(acid)

        total_acids = sum(probabilities.values())
        for acid in probabilities:
            probabilities[acid] /= total_acids

        x_ending_choices = list(x_ending_probabilities.keys()) + [0]  # Include option for no "X"s
        x_ending_weights = list(x_ending_probabilities.values()) + [1 - sum(x_ending_probabilities.values())]
        num_xs = random.choices(x_ending_choices, weights=x_ending_weights)[0]

        nucleotide_length = target_length - num_xs

        utr = ''
        for i in range(nucleotide_length):
            acid = random.choices(list(probabilities.keys()), weights=list(probabilities.values()))[0]
            utr += acid

        utr += 'X' * num_xs

        return utr
    
    def utr_3_shuffler(self, utr_list, target_length=25):
        x_starting_probabilities = self.calculate_x_starting_probabilities(utr_list)
        nucleotides = ['A', 'C', 'G', 'T']
        probabilities = {acid: 0 for acid in nucleotides}

        for utr in utr_list:
            for acid in nucleotides:
                probabilities[acid] += utr.count(acid)

        total_acids = sum(probabilities.values())
        for acid in probabilities:
            probabilities[acid] /= total_acids

        x_ending_choices = list(x_starting_probabilities.keys()) + [0]  # Include option for no "X"s
        x_ending_weights = list(x_starting_probabilities.values()) + [1 - sum(x_starting_probabilities.values())]
        num_xs = random.choices(x_ending_choices, weights=x_ending_weights)[0]

        nucleotide_length = target_length - num_xs

        utr = ''
        utr += 'X' * num_xs
        
        for i in range(nucleotide_length):
            acid = random.choices(list(probabilities.keys()), weights=list(probabilities.values()))[0]
            utr += acid

        return utr

    def turn_two(self):
        # Generate a random microprotein sequence with lengths based on the mean and standard deviation of unknown_orfs, ie, those that are not positively labeled but are not decoys
        random_aa_seq = []
        n_random_smORFs = self.args.n_random_smORFs = int(self.args.n_random_smORFs)
        while len(random_aa_seq) < n_random_smORFs:
            length = int(np.random.normal(self.mean_aa, self.std_aa))
            if length > 0:
                random_aa_seq.append(self.protein_shuffler(self.unknown_orfsAASeq, length))
                random_aa_seq = [self.move_M(i) for i in random_aa_seq]

        # Generate random UTR_5 sequences
        utr_5_list = self.unknown_sequences['utr_5'].tolist()
        random_utr_5 = []
        while len(random_utr_5) < n_random_smORFs:
            length = int(np.random.normal(self.mean_5, self.std_5))
            if length > 0:
                random_utr_5.append(self.utr_5_shuffler(utr_5_list, 25))

        # Generate a random utr_3 with lengths based on the mean and standard deviation of unknown_orfs, ie, those that are not positively labeled but are not decoys
        utr_3_list = self.unknown_sequences['utr_3'].tolist()
        random_utr_3 = []
        while len(random_utr_3) < n_random_smORFs:
            length = int(np.random.normal(self.mean_3, self.std_3))
            if length > 0:
                random_utr_3.append(self.utr_3_shuffler(utr_3_list, 25))

        random_aa_length = [len(i) for i in random_aa_seq]

        # Convert aa_seq to DNA, thus creating a random CDS sequence not biased by the codon usage
        random_cds_seq = []
        for i in random_aa_seq:
            dna = ''
            for j in i:
                dna += random.choice(self.codonTable[j])
            random_cds_seq.append(dna)

        # Create a 'type' column
        random_type = 'Random'

        # Create a 'local' column
        random_local = 'Random'

        # Make a dataframe of the random sequences with IDs
        random_df = pd.DataFrame({'orf_id': ['random_' + str(i) for i in range(n_random_smORFs)],
                                  'type': "Random",
                                  'aa_seq': random_aa_seq,
                                  'cds_seq': random_cds_seq,
                                  'utr_5': random_utr_5,
                                  'utr_3': random_utr_3,
                                  'length': random_aa_length,
                                  'type': random_type,
                                  'local': random_local})

        # Filter by length of aa_seq
        random_df = random_df[random_df['length'] >= 30]
        self.randomDF = random_df[random_df['length'] <= 150]

    def combine_databases(self):
        
        if self.args.mode == "make_random_genes":
            
            # Append the random sequences to the smorfs dataframe
            smorfs_random = pd.concat([self.unknown_sequences, self.randomDF], ignore_index=True)
            print(smorfs_random.shape)

            # Calculate length of utr_5, utr_3
            smorfs_random['utr_5_length'] = smorfs_random['utr_5'].apply(len)
            smorfs_random['utr_3_length'] = smorfs_random['utr_3'].apply(len)

            # Plot the distribution of sequence length
            sns.set(style="whitegrid")
            sns.set(rc={'figure.figsize': (11.7, 8.27)})   
            ax = sns.boxplot(x="type", y="length", data=smorfs_random)
            # plt.show()
            plt.savefig(f'{self.plotsDir}/database_sequence_length_distribution.png', dpi=300)

            # save to csv
            smorfs_random.to_csv(self.combinedDatabaseDF,
                index=False)
        else:
            self.positive_and_unknown_sequences = pd.read_csv(self.sequencesWithFunctions)
            uniprot_smorfs_random = pd.concat([self.positive_and_unknown_sequences, self.randomDF], ignore_index=True)
            print(uniprot_smorfs_random.shape)

            # Calculate length of utr_5, utr_3
            uniprot_smorfs_random['utr_5_length'] = uniprot_smorfs_random['utr_5'].apply(len)
            uniprot_smorfs_random['utr_3_length'] = uniprot_smorfs_random['utr_3'].apply(len)
            uniprot_smorfs_random['length'] = pd.to_numeric(uniprot_smorfs_random['length'], errors='coerce')
            # show distribution of legnth of sequences by type

            sns.set(style="whitegrid")
            sns.set(rc={'figure.figsize': (11.7, 8.27)})
            ax = sns.boxplot(x="type", y="length", data=uniprot_smorfs_random)
            # plt.show()
            plt.savefig(f'{self.plotsDir}/database_sequence_length_distribution.png', dpi=300)

            # save to csv
            uniprot_smorfs_random.to_csv(self.combinedDatabaseDF,
                index=False)
            self.uniprot_smorfs_random = uniprot_smorfs_random
             
    def reduce_protein_features(self):

        # Prepare data for feature extraction
        ids = self.uniprot_smorfs_random["orf_id"].values.tolist()
        aa_seqs = self.uniprot_smorfs_random['aa_seq'].values.tolist()
        cds_seqs = self.uniprot_smorfs_random['cds_seq'].values.tolist()
        upstream_seqs = self.uniprot_smorfs_random['utr_5'].tolist()
        downstream_seqs = self.uniprot_smorfs_random['utr_3'].tolist()
        type = self.uniprot_smorfs_random["type"].values.tolist()  
        local = self.uniprot_smorfs_random["local"].values.tolist() 

        # Are all the lists the same length?
        if len(ids) == len(aa_seqs) == len(cds_seqs) == len(upstream_seqs) == len(downstream_seqs) == len(type) == len(
                local):
            print("... " + str(len(ids)) + ".")
        else:
            print("You are missing either aa_seq, cds_seq, upstream_seqs, downstream_seqs, type, or local in your data. Please check your data.")
            
        # Extract features
        utr_length = self.args.utr_length
        utr_length = int(utr_length)
        k = self.args.kmer
        k = int(k)
        normalize = self.args.normalization

        features_instance = FeatureExtraction(ids, type, local, aa_seqs, cds_seqs, upstream_seqs, downstream_seqs,
                                              utr_length=utr_length, normalize=normalize, k=k)

        orfs_features = features_instance.feature_extraction()
        print(orfs_features.head())
        print(orfs_features.groupby(['label']).size().reset_index(name='counts'))