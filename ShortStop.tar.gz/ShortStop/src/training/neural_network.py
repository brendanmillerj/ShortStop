import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Dense, Concatenate, BatchNormalization, Activation, Dropout
from tensorflow.keras.utils import to_categorical, plot_model
from tensorflow.keras.optimizers import Adam
from keras.wrappers.scikit_learn import KerasClassifier
import tensorflow as tf
import joblib

from ..pipeline import PipelineStructure

tf.random.set_seed(2016)

class NeuralNetwork(PipelineStructure):
    def __init__(self, args):
        super().__init__(args=args)
        self.set_training_attributes()
        self.labels = None
        self.dnaData = None
        self.aaData = None
        self.orfIds = None
        self.data = None
        self.labelTrain = None
        self.dnaTest = None
        self.aaTest = None
        self.labelTest = None
        self.orfTrain = None
        self.orfTest = None
        self.history = None
        self.best_model = None
        self.scaler = None

    def fit_transform_scaler(self, train_data):
        """Fit the scaler with training data and transform it."""
        self.scaler = StandardScaler().fit(train_data)
        return self.scaler.transform(train_data)

    def transform_data(self, data):
        """Transform data with the already fitted scaler."""
        return self.scaler.transform(data)

    def clean_data(self):
        # Import features
        features = pd.read_csv(self.orfsFeatures)
        features = features[features.local != 'Unknown']
        features = features.drop(features.filter(regex='cds|local|type').columns, axis=1)

        # Import labels
        labels = pd.read_csv(self.labelPropagationDF)
        labels = labels[labels.label_prop != 'Unknown']

        # Merge features and labels
        df = pd.merge(features, labels, on='orf_id')

        # Split DNA and AA features, and labels
        self.dnaData = df.loc[:, df.columns.str.startswith(('5_prime', '3_prime', 'kozak', 'first_50'))].to_numpy()
        np.savetxt(f"{self.modelsDir}/dna_columns.txt", df.loc[:, df.columns.str.startswith(('5_prime', '3_prime', 'kozak', 'first_50'))].columns, fmt='%s')
        aa_columns = [col for col in df if not any(prefix in col for prefix in ('3_prime', '5_prime', 'kozak', 'label', 'orf_id', 'cds', 'first_50', 'type', 'local', 'umap_0', 'umap_1', 'umap_2'))]
        np.savetxt(f"{self.modelsDir}/aa_columns.txt", df[aa_columns].columns, fmt='%s')
        self.aaData = df[aa_columns].to_numpy()
        self.orfIds = df['orf_id'].values

        # Convert labels to one-hot encoding
        mapping = {"RiboSeq": 0, "Cytoplasm": 1, "Secreted": 2}
        df['label_encoded'] = df['label_prop'].map(mapping)
        self.labels = to_categorical(df['label_encoded'].values)

    def a2000(self):
        dna_train, self.dnaTest, aa_train, self.aaTest, self.labelTrain, self.labelTest, self.orfTrain, self.orfTest = train_test_split(
            self.dnaData, self.aaData, self.labels, self.orfIds, test_size=0.2, stratify=self.labels)

        # Scale the data
        train_data = np.concatenate((dna_train, aa_train), axis=1)
        # Show shape of self.aaData and self.dnaData
        print(f"Number of DNA features: {dna_train.shape[1]}")
        print(f"Number of AA features: {aa_train.shape[1]}")
        self.data = self.fit_transform_scaler(train_data)
        joblib.dump(self.scaler, f"{self.modelsDir}/scaler.save")

    def tune_hyperparameters(self):
        def create_model(data_shape):
            def model_fn(nodes_layer_one=512, nodes_layer_two=128, dropout_rate=0.4, learning_rate=0.0001):
                input_layer = Input(shape=(data_shape,))
                x = Dropout(dropout_rate)(Activation('relu')(BatchNormalization()(Dense(nodes_layer_one)(input_layer))))
                if nodes_layer_two > 0:
                    x = Dropout(dropout_rate)(Activation('relu')(BatchNormalization()(Dense(nodes_layer_two)(x))))
                output_layer = Dense(3, activation='softmax')(x)
                model = Model(inputs=input_layer, outputs=output_layer)
                model.compile(loss='categorical_crossentropy', optimizer=Adam(learning_rate), metrics=['accuracy'])
                return model
            return model_fn

        model = KerasClassifier(build_fn=create_model(self.data.shape[1]), verbose=0)
        param_grid = {
            'nodes_layer_one': [256, 512],
            'nodes_layer_two': [0, 32],
            'dropout_rate': [0.1, 0.2],
            'validation_split': [0.2],
            'learning_rate': [0.001, 0.0001],
            'batch_size': [16, 32],
            'epochs': [24]
        }
        grid = GridSearchCV(estimator=model, param_grid=param_grid, n_jobs=-1, cv=3)
        grid_result = grid.fit(self.data, self.labelTrain)

        self.best_model = grid_result.best_estimator_.model
        print('Best score:', grid_result.best_score_)
        print('Best params:', grid_result.best_params_)
        
        # Save the model history
        self.history = pd.DataFrame(self.best_model.history.history)
        self.history.to_csv(f"{self.modelsDir}/model_history.csv", index=False)
        

    def test_model(self):
        test_data = np.concatenate((self.dnaTest, self.aaTest), axis=1)
        test_data = self.transform_data(test_data)
        test_acc = self.best_model.evaluate(test_data, self.labelTest)
        print('Test accuracy:', test_acc[1])

        probs = self.best_model.predict(test_data)
        pred_labels = np.argmax(probs, axis=1)

        # Create a confusion matrix
        cm = confusion_matrix(self.labelTest.argmax(axis=1), pred_labels)

        # Compute precision, recall, and F1 score
        precision = precision_score(self.labelTest.argmax(axis=1), pred_labels, average=None)
        recall = recall_score(self.labelTest.argmax(axis=1), pred_labels, average=None)
        f1score = f1_score(self.labelTest.argmax(axis=1), pred_labels, average=None)

        # print results
        print('Confusion Matrix:\n', cm)
        print('\nPrecision:', precision)
        print('Recall:', recall)
        print('F1 Score:', f1score, '\n')

        # Save model
        self.best_model.save(f'{self.modelsDir}/best_model.h5')

    def plot_model_architecture(self):
        plt.clf()
        plot_model(self.best_model, show_shapes=True, to_file=self.modelArchitecturePlot)
        
    def plot_metrics(self):
        plt.clf()
        plt.plot(self.history['accuracy'], label='train accuracy')
        plt.plot(self.history['val_accuracy'], label='val accuracy')
        plt.plot(self.history['loss'], label='train loss')
        plt.plot(self.history['val_loss'], label='val loss')
        plt.title('Model accuracy and loss')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy/Loss')
        plt.legend(loc='best')
        plt.savefig(self.modelAccuracyPlot, dpi=300)
 
