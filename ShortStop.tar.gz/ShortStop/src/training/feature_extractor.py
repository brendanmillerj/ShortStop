import sys
import pandas as pd

from ..pipeline import PipelineStructure
from ..converters import FeatureExtraction

class FeatureExtractor(PipelineStructure):
    def __init__(self, args):
        super().__init__(args=args)
        self.set_training_attributes()

    def extract_features(self):
        if self.args.mode == "training" or self.args.mode == "demo":
            positive_unknown_decoy_sequences = pd.read_csv(self.combinedDatabaseDF)

            # remove seq in smorfs not in seq
            ids = positive_unknown_decoy_sequences["orf_id"].values.tolist()
            aa_seqs = positive_unknown_decoy_sequences['aa_seq'].values.tolist()
            cds_seqs = positive_unknown_decoy_sequences['cds_seq'].values.tolist()
            upstream_seqs = positive_unknown_decoy_sequences['utr_5'].tolist()
            downstream_seqs = positive_unknown_decoy_sequences['utr_3'].tolist()

            type = positive_unknown_decoy_sequences["type"].values.tolist()  # This is to append the type to the features
            local = positive_unknown_decoy_sequences["local"].values.tolist()  # This is to append the cc to the features
            
             # Are all the lists the same length?
            if len(ids) == len(aa_seqs) == len(cds_seqs) == len(upstream_seqs) == len(downstream_seqs) == len(type) == len(
                    local):
                print("There are " + str(len(ids)) + " short protein-coding genes being considered for training.")
            else:
                print("You are missing ids, aa_seqs, cds_seqs, upstream_seqsm, downstream_seqs, type, or local data.")

            #Extract features
            utr_length = self.args.utr_length
            utr_length = int(utr_length)
            k = self.args.kmer
            k = int(k)
            normalize = self.args.normalization # This is to normalize the features if the user desires

            features_instance = FeatureExtraction(ids, type, local, aa_seqs, cds_seqs, upstream_seqs, downstream_seqs, utr_length = utr_length, normalize = normalize, k = k) 
            orfs_features = features_instance.feature_extraction()

            orfs_features['type'] = type
            orfs_features['local'] = local
            
            print(orfs_features.groupby(['label']).size().reset_index(name='counts'))
        
            orfs_features.to_csv(self.orfsFeatures, index=False)
            orfs_features.to_csv(self.orfsFeaturesInTrainingModel, index=False)
            print("Feature extraction completed.")
        else:
            unknown_smorfs = pd.read_csv(self.unknown_sequences)
            unknown_smorfs['type'] = 'unknown_orfs'
            unknown_smorfs['local'] = 'ToBePredicted'
     
            ids = unknown_smorfs["orf_id"].values.tolist()
            aa_seqs = unknown_smorfs['aa_seq'].values.tolist()
            cds_seqs = unknown_smorfs['cds_seq'].values.tolist()
            upstream_seqs = unknown_smorfs['utr_5'].tolist()
            downstream_seqs = unknown_smorfs['utr_3'].tolist()
            type = unknown_smorfs["type"].values.tolist()  
            local = unknown_smorfs["local"].values.tolist()

            #Extract features
            utr_length = self.args.utr_length
            utr_length = int(utr_length)
            k = self.args.kmer
            k = int(k)
            normalize = self.args.normalization

            features_instance = FeatureExtraction(ids, type, local, aa_seqs, cds_seqs, upstream_seqs, downstream_seqs, utr_length = utr_length, normalize = normalize, k = k) 
            orfs_features = features_instance.feature_extraction()
            
            orfs_features.to_csv(self.orfsFeatures, index=False)