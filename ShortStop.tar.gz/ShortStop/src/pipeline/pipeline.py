import os
import shutil
from ..training import SequenceExtractor, NegativeSet, DatabaseCombiner, FeatureExtractor, LabelPropagator, NeuralNetwork, NeuralNetworkCustomFeatures
from ..prediction import smORFPredictor

class Pipeline:
    def __init__(self, args):
        self.args = args
        self.outdir = args.outdir
    
    def train(self):
        print("▶️ You have successfully initiated training...")
        seq_extractor = SequenceExtractor(args=self.args)
        seq_extractor.create_positive_gtf()
        print("✅ GTF for positive ORFs completed.")
        seq_extractor.extract_sequences()
        print("✅ Amino acids and DNA for each ORF extracted.")

        print("⏳Generating random decoy sequences based on your putative smORFs...")
        decoy = NegativeSet(args=self.args)
        decoy.turn_two()
        decoy.combine_databases()
        print("✅ Random decoy sequences generated.")
        print("Extracting features...")
        feature_extractor = FeatureExtractor(args=self.args)
        feature_extractor.extract_features()
        print("✅ ORF feature extraction completed.")

        if self.args.keep:
            print("🛑 Skipping label propagation.")
            label_propagator = LabelPropagator(args=self.args)
            label_propagator.create_original_data_frame()   
        else: 
            print("⏳Initiating label propagation to give your putative smORF a label for training...")
            label_propagator = LabelPropagator(args=self.args)
            label_propagator.reduce_features()
            label_propagator.plot_3d_scatter()
            label_propagator.propagate_labels()
            label_propagator.plot_propagated_3d_scatter()
            label_propagator.create_label_propagation_data_frame()
            print("✅ Label propagation completed.")

        print("⏳Starting neural network training...")
        nn = NeuralNetwork(args=self.args)
        nn.clean_data()
        nn.a2000()
        print("Starting hyperparameter tuning...")
        nn.tune_hyperparameters()
        nn.test_model()
        nn.plot_model_architecture()
        nn.plot_metrics()
        print("✅ Neural network training completed.")
    
    def generate_random_decoy_sequences(self):
        print("⏳Extracting unknown sequences...")
        seq_extractor = SequenceExtractor(args=self.args)
        seq_extractor.extract_unknown_sequences()

        print("⏳Preparing Negative Set...")
        decoy = NegativeSet(args=self.args)
        decoy.turn_two()
        decoy.combine_databases()
        print("✅ Random decoy sequences generated.")
        
    def custom_feature_training(self):
        print("⏳Custom Feature Training Initiated.")
        label_propagator = LabelPropagator(args=self.args)
        label_propagator.reduce_features()
        label_propagator.plot_3d_scatter()
        label_propagator.propagate_labels()
        label_propagator.plot_propagated_3d_scatter()
        label_propagator.create_label_propagation_data_frame()

        nn = NeuralNetworkCustomFeatures(args=self.args)
        nn.clean_data()
        nn.split_data_double_play()
        nn.tune_hyperparameters()
        nn.test_model()
        nn.plot_model_architecture()
        print("✅ Custom Feature Training Completed.")
        
    def feature_extract(self):
        print("⏳Starting feature extraction process...")
        seq_extractor = SequenceExtractor(args=self.args)
        seq_extractor.extract_unknown_sequences()
        
        feature_extractor = FeatureExtractor(args=self.args)
        feature_extractor.extract_features()
        print("✅ Feature extraction completed.")
        
    def predict(self):
        
        print("⏳Sequences are being fielded...")
        seq_extractor = SequenceExtractor(args=self.args)
        seq_extractor.extract_unknown_sequences()
        print("✅ Sequences fielded.")

        print("⏳Extracting features...")
        feature_extractor = FeatureExtractor(args=self.args)
        feature_extractor.extract_features()
        print("✅ Feature extractions are set and completed.")
        
        print("⏳Throwing features into the prediction algorithm...")
        predictions = smORFPredictor(args=self.args)
        predictions.dansby()
        print("✅ Predictions out and completed!")
        
    def demo(self):
        print("▶️ You have successfully initiated the demo...")
        
        seq_extractor = SequenceExtractor(args=self.args)
        seq_extractor.create_positive_gtf()
        print("✅ GTF for positive ORFs completed.")
        seq_extractor.extract_sequences()
        print("✅ Amino acids and DNA for each ORF extracted.")

        print("⏳Generating random decoy sequences based on your putative smORFs...")
        decoy = NegativeSet(args=self.args)
        decoy.turn_two()
        decoy.combine_databases()
        print("✅ Random decoy sequences generated.")
        
        print("⏳Extracting features...")
        feature_extractor = FeatureExtractor(args=self.args)
        feature_extractor.extract_features()
        print("✅ ORF feature extraction completed.")

        print("⏳Initiating label propagation to give your putative smORF a label for training...")
        label_propagator = LabelPropagator(args=self.args)
        print("🛑 Early termination of label propagation for demo purposes.")

        print("⏳Starting neural network training...")
        nn = NeuralNetwork(args=self.args)
        print("🛑 Early termination of hyperparameter tuning for demo purposes.")
        
        print("⏳Throwing features into the prediction algorithm...")
        predictions = smORFPredictor(args=self.args)
        predictions.dansby()
        print("✅ Predictions out and completed!")
        
        self.__cleanup_output_directory(self.outdir)  # Replace "--outdir" with the actual variable holding the output directory path
        
        print("✅ Demo completed.")
        
    def __cleanup_output_directory(self, outdir):
        """Removes all directories and files in the specified output directory and recreates the directory."""
        try:
            # Remove the output directory and all its contents
            shutil.rmtree(outdir)
            print(f"🧹 Output directory '{outdir}' cleaned up successfully.")
        except Exception as e:
            print(f"Error cleaning up output directory '{outdir}': {e}")

        