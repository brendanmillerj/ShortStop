import os
from protlearn.features import ctd, ctdd, qso, apaac, cksaap
import pandas as pd
import numpy as np
import time
from collections import Counter
import math

class FeatureExtraction:
    def __init__(self, ids, types, labels, aa_seqs, cds_seqs, upstream_seqs, downstream_seqs, utr_length, k, normalize = None):
        self.ids = ids
        self.types= types
        self.labels = labels
        self.aa_seq = aa_seqs
        self.cds_seq = cds_seqs
        self.upstream_seq = upstream_seqs
        self.downstream_seq = downstream_seqs
        self.utr_length = utr_length
        self.normalize = normalize
        self.k = k

        # Convert the sequences to uppercase 
        for i in range(len(self.aa_seq)):
            self.aa_seq[i] = self.aa_seq[i].upper()

        for i in range(len(self.cds_seq)):
            self.cds_seq[i] = self.cds_seq[i].upper()

        for i in range(len(self.upstream_seq)):
            self.upstream_seq[i] = self.upstream_seq[i].upper()

        for i in range(len(self.downstream_seq)):
            self.downstream_seq[i] = self.downstream_seq[i].upper()

        # If the self.upstream_seq is less than self.utr_length nucleotides, pad with Xs
        for i in range(len(self.upstream_seq)):
            if len(self.upstream_seq[i]) < self.utr_length:
                self.upstream_seq[i] =  self.upstream_seq[i] + 'X' * (self.utr_length - len(self.upstream_seq[i]))

        # Keep only the last self.utr_length nucleotides of upstream_seq
        for i in range(len(self.upstream_seq)):
            self.upstream_seq[i] = self.upstream_seq[i][-self.utr_length:]

        # If the self.downstream_seq is less than self.utr_length nucleotides, pad with Xs
        for i in range(len(self.downstream_seq)):
            if len(self.downstream_seq[i]) < self.utr_length:
                self.downstream_seq[i] ='X' * (self.utr_length - len(self.downstream_seq[i])) + self.downstream_seq[i]

        # Keep only the last self.utr_length nucleotides of downstream_seq
        for i in range(len(self.downstream_seq)):
            self.downstream_seq[i] = self.downstream_seq[i][:self.utr_length]


    def kmer_frequency_list(self, sequences):
        scaled_freqs_list = []

        for sequence in sequences:
            # Generate k-mers for the sequence
            kmers = [sequence[i:i+self.k] for i in range(len(sequence) - self.k + 1)]
            freqs = Counter(kmers)
            
            # Normalize frequencies within the sequence
            total_kmers = len(kmers)
            freqs = {kmer: freq / total_kmers for kmer, freq in freqs.items()}
            
            # Apply min-max scaling within each sequence
            if freqs:
                min_freq = min(freqs.values())
                max_freq = max(freqs.values())
                range_freq = max_freq - min_freq
                if range_freq > 0:
                    scaled_freqs = {kmer: (freq - min_freq) / range_freq for kmer, freq in freqs.items()}
                else:
                    # In case all k-mers have the same frequency, assign them all a value of 1
                    scaled_freqs = {kmer: 1 for kmer in freqs}
            else:
                scaled_freqs = {}
            
            scaled_freqs_list.append(scaled_freqs)
                    
        return scaled_freqs_list
    
    def kozak_score(self, sequences):
        
        score_list = []
        for sequence in sequences:
                score = 3 * (sequence[0] == 'G') + (sequence[1] == 'C') + (sequence[2] == 'C') + \
                3 * (sequence[3] in ['A', 'G']) + (sequence[4] == 'C') + (sequence[5] == 'C') + \
                3 * (sequence[9] == 'G')
                score_list.append(score)
        return score_list
    
    def feature_extraction(self):
        time_start = time.time()

        # If normalize is set to True, normalize the features according to the following methods:
        aa_log_list = []
        for sequence in self.aa_seq:
            aa_log = math.log(len(sequence))
            aa_log_list.append(aa_log)
        aa_log_list = np.array(aa_log_list)

        aa_sqrt_list = []
        for sequence in self.aa_seq:
            aa_sqrt = math.sqrt(len(sequence))
            aa_sqrt_list.append(aa_sqrt)
        aa_sqrt_list = np.array(aa_sqrt_list)

        aa_inverse_list = []
        for sequence in self.aa_seq:
            aa_inverse = 1/len(sequence)
            aa_inverse_list.append(aa_inverse)
        aa_inverse_list = np.array(aa_inverse_list)

        # Initialize lists to store features and labels
        features_list = []
        labels_list = []

        # Compute features and labels for each method and add them to the respective lists
        for method in [ctdd, cksaap, apaac, qso]:
            
            np.random.seed(0)
            if method == apaac:
                features, labels = method(self.aa_seq, lambda_=28)
                features = features.astype(np.float64)
            elif method == qso:
               features, features2, labels = method(self.aa_seq, d=28)
               features = features.astype(np.float64)
            elif method == cksaap:
                features, labels = method(self.aa_seq)
                # Add prefix ctd to the labels
                labels = [f'cksaap{label}' for label in labels]
                # Convert features to float64
                features = features.astype(np.float64)
            else:
                features, labels = method(self.aa_seq)
                # Convert features to float64
                features = features.astype(np.float64)
            
            
            if self.normalize == "sqrt":
                features = features/aa_sqrt_list[:,np.newaxis]
            elif self.normalize == "log":
                features = features/aa_log_list[:,np.newaxis]
            elif self.normalize == "inverse":
                features = features/aa_inverse_list[:,np.newaxis]
            else:
                features = features
            labels = [str(i) for i in labels]
            features_list.append(features)
            labels_list += labels

        # Concatenate features and labels into a DataFrame
        features = np.concatenate(features_list, axis=1)
        aa_df = pd.DataFrame(features, columns=labels_list)
        aa_df['orf_id'] = self.ids
        
        # Generate upstream k-mer frequency dataframe
        upstream_sequences = [seq.upper() for seq in self.upstream_seq]
        upstream_freq = self.kmer_frequency_list(upstream_sequences)
        cds_upstream_kmer = pd.DataFrame(upstream_freq)
        cds_upstream_kmer = cds_upstream_kmer.add_prefix('5_prime_')
        cds_upstream_kmer['orf_id'] = self.ids
        
        # Generate downstream k-mer frequency dataframe
        downstream_sequences = [seq.upper() for seq in self.downstream_seq]
        downstream_freq = self.kmer_frequency_list(downstream_sequences)
        cds_downstream_kmer = pd.DataFrame(downstream_freq)
        cds_downstream_kmer = cds_downstream_kmer.add_prefix('3_prime_')
        cds_downstream_kmer['orf_id'] = self.ids
        
        # Merge the upstream and downstream k-mer frequency dataframes 
        kmer_df = pd.merge(cds_upstream_kmer, cds_downstream_kmer, on='orf_id')
        kmer_df = kmer_df.fillna(0)
        
        # Kozak score
        kozak_context = [seq[-6:] + seq2[:4] for seq, seq2 in zip(self.upstream_seq, self.cds_seq)]
        kozak_score = self.kozak_score(kozak_context)
        kozak_df = pd.DataFrame(kozak_score, columns=['kozak_score'])
        kozak_df['orf_id'] = self.ids

        # Extract the first 50 nucleotides of the CDS
        first_50 = [seq[:50] for seq in self.cds_seq]
        first_50_kmer = self.kmer_frequency_list(first_50)
        first_50_kmer = pd.DataFrame(first_50_kmer)
        first_50_kmer = first_50_kmer.add_prefix('first_50_')
        first_50_kmer['orf_id'] = self.ids
        first_50_kmer = first_50_kmer.fillna(0)

        # Merge the dataframes
        df = pd.merge(kmer_df, kozak_df, on='orf_id')
        df = pd.merge(df, first_50_kmer, on='orf_id')
        df = pd.merge(df, aa_df, on='orf_id')
                
        # Add labels and types
        df['label'] = self.labels
        df['type'] = self.types

        return df