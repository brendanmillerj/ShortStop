from .dirtools import check_dir, check_multi_dirs
