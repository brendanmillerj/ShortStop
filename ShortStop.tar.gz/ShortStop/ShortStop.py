#!/usr/bin/python3

import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Dense, Concatenate, BatchNormalization, Activation, Dropout
from tensorflow.keras.utils import to_categorical, plot_model
from tensorflow.keras.optimizers import Adam
from scikeras.wrappers import KerasClassifier
import joblib
import random

from src.pipeline import Pipeline

np.random.seed(2016)
random.seed(2016)
tf.random.set_seed(2016)

class ShortStop:
    def __init__(self):
        self.args = self.__get_args()

    def __get_args(self):
        self.main_parser = argparse.ArgumentParser(description="ShortStop",
                                                   formatter_class=argparse.ArgumentDefaultsHelpFormatter)

        self.mode_parser = self.main_parser.add_argument_group("Mode input options")

        self.mode_parser.add_argument("mode", metavar="Mode",
                                      help="Mode to run the pipeline for.\nList of Modes: "
                                           "training, generate_random_decoy_sequences, feature_extract, predict, train_with_custom_features")

        self.args = self.main_parser.parse_args(sys.argv[1:2])
        self.mode = self.args.mode
        self.parser = argparse.ArgumentParser(description="Run pipeline in %s mode" % self.mode,
                                              prog=" ".join(sys.argv[0:2]),
                                              formatter_class=argparse.ArgumentDefaultsHelpFormatter)

        self.general_args = self.parser.add_argument_group("General Parameters")
        self.general_args.add_argument("mode", metavar=self.mode)
        self.general_args.add_argument("--outdir", "-o", help="Inform the output directory", default="shortstop_output")
        self.general_args.add_argument("--threads", "-p", help="Number of threads to be used.", default=1)

        self.__configure_mode()

        args = self.parser.parse_args()
        return args

    def __configure_mode(self):
        if self.mode == 'training':
            self.__set_train_mode()
        elif self.mode == "make_random_genes":
            self.__make_random_genes()
        elif self.mode == 'feature_extract':
            self.__set_feature_extract_mode() 
        elif self.mode == 'predict':
            self.__set_predict_mode()
        elif self.mode == 'train_with_custom_features':
            self.__set_train_mode_with_custom_features()
        elif self.mode == 'demo':
            self.__set_demo_mode()

    def __set_train_mode(self):
        self.modeArguments = self.parser.add_argument_group("Trainig mode options")
        self.modeArguments.add_argument("--positive_gtf", help="Provide the reference gtf file", default = 'demo_data/gencode.v43.primary_assembly.basic.annotation.gtf')
        self.modeArguments.add_argument("--positive_ids", help="Provide the positive data frame", default = 'demo_data/uniprot_entry_ensembl_ids.csv')
        self.modeArguments.add_argument("--positive_functions", help="Provide the positive functional protein assignment data frame, such as cellular localization", default = 'demo_data/shortstop_training_cc.csv')
        self.modeArguments.add_argument("--genome", help="genome fasta file", default = 'demo_data/GRCh38.primary_assembly.genome.fa')
        self.modeArguments.add_argument("--putative_smorfs_gtf", help="Provide the to_be_predicted gtf file", default='demo_data/gencode_smorfs.gtf')
        self.modeArguments.add_argument("--utr_length", help="Provide the length of UTRs. Note the memory substantially increases beyond 25 bases", default=25)
        self.modeArguments.add_argument("--n_random_smORFs", help="Provide the number of random smORFs you want to generate. Consider class balancing.", default=2500)
        self.modeArguments.add_argument("--kmer", help="Provide the kmer size for nucleotide data processing.", default=4)
        self.modeArguments.add_argument("--n_neighbors", help="Number of neighbors for UMAP", default=50)
        self.modeArguments.add_argument("--gamma", help="Gamma initialization for label spreading. Increase the number for greater strictness. Deafult set at 1. ", default=50)
        self.modeArguments.add_argument("--normalization", help="If considering protein length normalziation, options include inverse, sqrt, and log transformation of feature values. ", default="none")
        self.modeArguments.add_argument("--keep", help="Use label propagation", action="store_true", default=False)
        
    def __make_random_genes(self):
        self.modeArguments = self.parser.add_argument_group("Options")
        self.modeArguments.add_argument("--genome", help="genome fasta file")
        self.modeArguments.add_argument("--putative_smorfs_gtf", help="Provide the to_be_predicted gtf file")
        self.modeArguments.add_argument("--utr_length", help="Provide the length of UTRs. Note the memory substantially increases beyond 25 bases", default=25)
        self.modeArguments.add_argument("--kmer", help="Provide the kmer size for nucleotide data processing.", default=4)
        self.modeArguments.add_argument("--n_random_smORFs", help="Provide the number of random smORFs you want to generate. Consider class balancing.", default=2500)

    def __set_feature_extract_mode(self):
        self.modeArguments = self.parser.add_argument_group("Options")
        self.modeArguments.add_argument("--genome", help="genome fasta file", default = 'demo_data/GRCh38.primary_assembly.genome.fa')
        self.modeArguments.add_argument("--putative_smorfs_gtf", help="Provide the to_be_predicted gtf file")
        self.modeArguments.add_argument("--utr_length", help="Provide the length of UTRs. Note the memory substantially increases beyond 25 bases", default=25)
        self.modeArguments.add_argument("--kmer", help="Provide the kmer size for nucleotide data processing.", default=4)
        self.modeArguments.add_argument("--normalization", help="If considering protein length normalziation, options include inverse, sqrt, and log transformation of feature values. ", default="none")

    def __set_predict_mode(self):
        self.modeArguments = self.parser.add_argument_group("Predict mode options")
        self.modeArguments.add_argument("--genome", help="genome fasta file", default = 'demo_data/GRCh38.primary_assembly.genome.fa')
        self.modeArguments.add_argument("--putative_smorfs_gtf", help="Provide the to_be_predicted gtf file", default='demo_data/chr1_smorfs.gtf')
        self.modeArguments.add_argument("--utr_length", help="Provide the length of UTRs. Note the memory substantially increases beyond 25 bases", default=25)
        self.modeArguments.add_argument("--kmer", help="Provide the kmer size for nucleotide data processing.", default=4)
        self.modeArguments.add_argument("--normalization", help="If considering protein length normalziation, options include inverse, sqrt, and log transformation of feature values. ", default="none")
        self.modeArguments.add_argument("--orfs_features_in_training_model", help="Feature file of the orfs that were used to train the model. The default naming convention is: orfs_features.csv. This will be output from the training mode.", default = 'standard_prediction_model/orfs_features_in_training_model.csv')
        self.modeArguments.add_argument("--orfs_to_be_predicted", help="Feature file of the orfs that will be predicted. The default naming convention is: orfs_to_be_predicted.csv", default = 'shortstop_output/features/extracted_features_of_smorfs.csv')
        self.modeArguments.add_argument("--model_scaler", help="Scaler file of the model. The default naming convention is: scaler_params.csv. This will be output from the training mode.", default = 'standard_prediction_model/scaler.save')
        self.modeArguments.add_argument("--model", help="Model file. The default naming convention is: best_model.h5. This will be output from the training mode.", default = 'standard_prediction_model/best_model.h5')
        
    def __set_train_mode_with_custom_features(self):
        self.modeArguments = self.parser.add_argument_group("Options")
        self.modeArguments.add_argument("--positive_gtf", help="reference gtf file")
        self.modeArguments.add_argument("--positive_ids", help="Provide the positive data frame")
        self.modeArguments.add_argument("--positive_functions", help="Provide the positive cellular compartment protein assignment data frame")
        self.modeArguments.add_argument("--genome", help="genome fasta file")
        self.modeArguments.add_argument("--putative_smorfs_gtf", help="Provide the to_be_predicted gtf file")
        self.modeArguments.add_argument("--n_random_smORFs", help="Provide the number of random smORFs you want to generate. Consider class balancing.", default=2500)
        self.modeArguments.add_argument("--utr_length", help="Provide the length of UTRs. Note the memory substantially increases beyond 25 bases", default=25)
        self.modeArguments.add_argument("--kmer", help="Provide the kmer size for nucleotide data processing.", default=4)
        self.modeArguments.add_argument("--n_neighbors", help="Number of neighbors for UMAP", default=50)
        self.modeArguments.add_argument("--gamma", help="Gamma initialization for label spreading. Increase the number for greater strictness. Deafult set at 1. ", default=1)
        self.modeArguments.add_argument("--normalization", help="If considering protein length normalziation, options include inverse, sqrt, and log transformation of feature values. ", default="none")
        
    def __set_demo_mode(self):
        self.modeArguments = self.parser.add_argument_group("Demo mode options")
        self.modeArguments.add_argument("--positive_gtf", help="Provide the reference gtf file", default = 'demo_data/gencode.v43.primary_assembly.basic.annotation.gtf')
        self.modeArguments.add_argument("--positive_ids", help="Provide the positive data frame", default = 'demo_data/uniprot_entry_ensembl_ids.csv')
        self.modeArguments.add_argument("--positive_functions", help="Provide the positive functional protein assignment data frame, such as cellular localization", default = 'demo_data/shortstop_training_cc.csv')
        self.modeArguments.add_argument("--genome", help="genome fasta file", default = 'demo_data/GRCh38.primary_assembly.genome.fa')
        self.modeArguments.add_argument("--putative_smorfs_gtf", help="Provide the to_be_predicted gtf file", default='demo_data/gencode_smorfs.gtf')
        self.modeArguments.add_argument("--utr_length", help="Provide the length of UTRs. Note the memory substantially increases beyond 25 bases", default=25)
        self.modeArguments.add_argument("--n_random_smORFs", help="Provide the number of random smORFs you want to generate. Consider class balancing.", default=200)
        self.modeArguments.add_argument("--kmer", help="Provide the kmer size for nucleotide data processing.", default=2)
        self.modeArguments.add_argument("--n_neighbors", help="Number of neighbors for UMAP", default=50)
        self.modeArguments.add_argument("--gamma", help="Gamma initialization for label spreading. Increase the number for greater strictness. Deafult set at 1. ", default=1)
        self.modeArguments.add_argument("--normalization", help="If considering protein length normalziation, options include inverse, sqrt, and log transformation of feature values. ", default="none")
        self.modeArguments.add_argument("--orfs_features_in_training_model", help="Feature file of the orfs that were used to train the model. The default naming convention is: orfs_features.csv. This will be output from the training mode.", default = 'standard_prediction_model/orfs_features_in_training_model.csv')
        self.modeArguments.add_argument("--orfs_to_be_predicted", help="Feature file of the orfs that will be predicted. The default naming convention is: orfs_to_be_predicted.csv", default = 'shortstop_output/features/extracted_features_of_smorfs.csv')
        self.modeArguments.add_argument("--model_scaler", help="Scaler file of the model. The default naming convention is: scaler_params.csv. This will be output from the training mode.", default = 'standard_prediction_model/scaler.save')
        self.modeArguments.add_argument("--model", help="Model file. The default naming convention is: best_model.h5. This will be output from the training mode.", default = 'standard_prediction_model/best_model.h5')

    def execute(self):
        if self.mode == 'training':
            pipeline = Pipeline(args=self.args)
            pipeline.train()
        elif self.mode == "make_random_genes":
            pipeline = Pipeline(args=self.args)
            pipeline.generate_random_decoy_sequences()
        elif self.mode == 'feature_extract':
            pipeline = Pipeline(args=self.args)
            pipeline.feature_extract()  
        elif self.mode == 'predict':
            pipeline = Pipeline(args=self.args)
            pipeline.predict()
        elif self.mode == 'train_with_custom_features':
            pipeline = Pipeline(args=self.args)
            pipeline.custom_feature_training()
        elif self.mode == 'demo':
            pipeline = Pipeline(args=self.args)
            pipeline.demo()
        


if __name__ == '__main__':
    print("""     _______. __    __    ______   .______     .___________.    _______.___________.  ______   .______   
    /       ||  |  |  |  /  __  \  |   _  \    |           |   /       |           | /  __  \  |   _  \  
   |   (----`|  |__|  | |  |  |  | |  |_)  |   `---|  |----`  |   (----`---|  |----`|  |  |  | |  |_)  | 
    \   \    |   __   | |  |  |  | |      /        |  |        \   \       |  |     |  |  |  | |   ___/  
.----)   |   |  |  |  | |  `--'  | |  |\  \----.   |  |    .----)   |      |  |     |  `--'  | |  |      
|_______/    |__|  |__|  \______/  | _| `._____|   |__|    |_______/       |__|      \______/  | _|      
           """)

    print("""ShortStop is a platform that compares putative microproteins to randomly generated counterparts.""")
    shortstop = ShortStop()
    shortstop.execute()
